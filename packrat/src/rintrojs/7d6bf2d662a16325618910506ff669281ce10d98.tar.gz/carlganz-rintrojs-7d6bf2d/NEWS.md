# rintrojs 0.1.0.900

* Fix events bug (#7)

* Upgrade to Intro.js 2.3.0

