# Second resubmission

## Test environments

Local OS X, R 3.3.1 (Also tested on Travis CI)

Local Windows 10, R 3.3.1

Ubuntu 12.04, R 3.3.1 (on Travis CI)

## R CMD Check

0 errors | 0 warnings | 0 notes

## Changes

Added single quotes in description file around 'intro.js' and 'Shiny'

## Changes round 2

Expanded description, and included link to 'intro.js'

Changed email address because UCLA email won't work evidently

Thank you for your time